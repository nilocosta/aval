package br.com.s2it.desafio;

import br.com.s2it.desafio.arvoreBinaria.BinaryTree;
import br.com.s2it.desafio.numeroABC.NumeroABC;

public class ExecutaDesafio {

	public static void main(String[] args) {
		executaNumeroABC(1025, 51);
		buildBinaryTree();
	}
	
	public static void executaNumeroABC(int numeroA, int numeroB) {
		NumeroABC numeroABC = new NumeroABC();
		numeroABC.setA(numeroA);
		numeroABC.setB(numeroB);
		System.out.println("N�mero A = " + numeroA);
		System.out.println("N�mero B = " + numeroB);
		System.out.println("N�mero C = " + numeroABC.imprimeNumeroC());
	}
	
	public static void buildBinaryTree() {
		BinaryTree arvore = new BinaryTree(50);
		arvore.inserir(10);
		arvore.inserir(4);
		arvore.inserir(15);
		arvore.inserir(5);
		arvore.inserir(2);
		arvore.inserir(7);
		arvore.inserir(4);
		arvore.inserir(1);
		arvore.inserir(3);
		System.out.println(arvore.calculaNoSubsequente(arvore.root.left));
	}

}
