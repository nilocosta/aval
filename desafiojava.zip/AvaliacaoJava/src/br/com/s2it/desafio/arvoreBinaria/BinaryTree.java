package br.com.s2it.desafio.arvoreBinaria;

public class BinaryTree {
	int valor;
	public BinaryTree left, right, root;
	int maisAlto;

	public BinaryTree(int valor) {
		this.valor = valor;
	}

	public void inserir(int valor) {
		inserir(root, valor);
	}

	public void inserir(BinaryTree node, int valor) {
		if (node == null) {
			root = new BinaryTree(valor);
		} else {
			if (valor < node.valor) {
				if (node.left != null) {
					inserir(node.left, valor);
				} else {
					node.left = new BinaryTree(valor);
				}

			} else {
				if (node.right != null) {
					inserir(node.right, valor);
				} else {
					node.right = new BinaryTree(valor);
				}
			}
		}
	}

	public Integer calculaNoSubsequente(BinaryTree nodeRoot) {
		int leftValue = 0;
		int rightValue = 0;
		int total = 0;
		
		if (nodeRoot == null) {
			return 0;
		} else {
			leftValue = calculaNoSubsequente(nodeRoot.left);
			rightValue = calculaNoSubsequente(nodeRoot.right);

			total = nodeRoot.valor + leftValue + rightValue;
			
			return total;
		}
	}
}
